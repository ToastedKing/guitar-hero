/******************************************************************************
 *  Name:   Bryan Ayala-Vega 
 *  NetID:   
 *  Precept: 
 *
 *  Partner Name:    
 *  Partner NetID:   
 *  Partner Precept: 
 * 
 ******************************************************************************/

Which partner is submitting the program files? Bryan Ayala-Vega

Programming Assignment 6: Guitar Hero

Hours to complete assignment:
in class + 2 outside.


/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?
Yes, i had Quinn help me out on one of the tutors day and another one during TA on Tuesday.


/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?
Yes, i can not seen to find why the sound lingers for so long. 


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


